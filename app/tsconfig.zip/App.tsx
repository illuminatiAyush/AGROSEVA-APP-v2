// App.tsx
import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import AppNavigator from './src/navigation/AppNavigator';
import { SensorMock } from './src/services/SensorMock';
import { WeatherService } from './src/services/WeatherService'; 
import { useStore } from './src/store/useStore'; 

export default function App() {

  useEffect(() => {
    // 1. Start Sensor Heartbeat
    SensorMock.start();

    // 2. Load Weather Intelligence (The missing part)
    const forecast = WeatherService.getForecast();
    const alert = WeatherService.getAlerts();
    
    // 3. Save to Global Store
    useStore.getState().setWeather({ forecast, alert });

    return () => SensorMock.stop();
  }, []);

  return (
    <SafeAreaProvider>
      <StatusBar style="dark" />
      <AppNavigator />
    </SafeAreaProvider>
  );
}