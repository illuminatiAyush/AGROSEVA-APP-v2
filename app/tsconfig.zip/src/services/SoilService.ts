// Soil Monitoring Service (Mocked Data)

import { SoilData, ZoneSoilData } from '@/models/SoilData';
import { ZONES } from '@/utils/constants';

class SoilService {
  // Mock soil data generator
  private generateMockSoilData(zoneId: string): SoilData {
    const now = new Date();
    return {
      moisture: {
        value: Math.random() * 100,
        zone: zoneId,
        timestamp: now,
      },
      pH: {
        value: 5.5 + Math.random() * 3, // pH between 5.5-8.5
        zone: zoneId,
        timestamp: now,
      },
      npk: {
        nitrogen: Math.random() * 100,
        phosphorus: Math.random() * 100,
        potassium: Math.random() * 100,
        zone: zoneId,
        timestamp: now,
      },
      zone: zoneId,
      timestamp: now,
    };
  }

  async getSoilData(zoneId?: string): Promise<ZoneSoilData[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));

    if (zoneId) {
      const zone = ZONES.find(z => z.id === zoneId);
      if (!zone) throw new Error(`Zone ${zoneId} not found`);

      return [{
        zoneId: zone.id,
        zoneName: zone.name,
        soilData: this.generateMockSoilData(zone.id),
        lastUpdated: new Date(),
      }];
    }

    // Return data for all zones
    return ZONES.map(zone => ({
      zoneId: zone.id,
      zoneName: zone.name,
      soilData: this.generateMockSoilData(zone.id),
      lastUpdated: new Date(),
    }));
  }

  async getLatestSoilData(zoneId: string): Promise<SoilData> {
    await new Promise(resolve => setTimeout(resolve, 300));
    return this.generateMockSoilData(zoneId);
  }
}

export const soilService = new SoilService();

