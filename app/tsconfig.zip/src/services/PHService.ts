// pH Service Layer
// Handles pH data fetching with error handling and data transformation

import { hardwareClient, hardwareConfig } from '@/hardware/HardwareConfig';
import { PHData, clampPH } from '@/models/PHData';

/**
 * pH Service
 * 
 * Fetches pH data from hardware client and transforms it into app format.
 * Handles errors gracefully and ensures data validity.
 * 
 * This service layer isolates hardware details from the rest of the app.
 */
class PHService {
  /**
   * Fetch current pH reading
   * @returns PHData with pH value, timestamp, and source
   * @throws Error if sensor read fails
   */
  async fetchPH(): Promise<PHData> {
    try {
      const { pH, timestamp } = await hardwareClient.getPH();

      // Ensure pH is in valid range (0-14)
      const clampedPH = clampPH(pH);

      // Determine source based on hardware config
      const source = hardwareConfig.useRealHardware ? 'hardware' : 'mock';

      return {
        pH: Math.round(clampedPH * 10) / 10, // Round to 1 decimal
        timestamp,
        source,
      };
    } catch (error: any) {
      // Re-throw with context for better error handling in UI
      throw new Error(`Failed to fetch pH: ${error.message}`);
    }
  }
}

export const phService = new PHService();

