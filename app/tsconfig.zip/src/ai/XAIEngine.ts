// Explainable AI Engine - Human-readable reasoning

import { IrrigationRecommendation, FertilizerRecommendation } from '@/models/Recommendations';
import { SoilData } from '@/models/SoilData';
import { WeatherData } from '@/models/WeatherData';

class XAIEngine {
  // Generate human-readable explanation for irrigation decision
  explainIrrigationDecision(
    recommendation: IrrigationRecommendation,
    soilData: SoilData,
    weatherData: WeatherData
  ): string {
    const explanations: string[] = [];

    // Soil moisture explanation
    const moisture = soilData.moisture.value;
    if (moisture < 30) {
      explanations.push(`Soil moisture is critically low at ${moisture.toFixed(1)}%, which can cause severe crop stress.`);
    } else if (moisture < 40) {
      explanations.push(`Soil moisture is below optimal range (${moisture.toFixed(1)}%), indicating the need for irrigation.`);
    } else if (moisture > 80) {
      explanations.push(`Soil moisture is high (${moisture.toFixed(1)}%), so irrigation is not recommended to avoid waterlogging.`);
    } else {
      explanations.push(`Soil moisture is within acceptable range (${moisture.toFixed(1)}%).`);
    }

    // Weather impact explanation
    if (weatherData.rainfall > 5) {
      explanations.push(`Expected rainfall of ${weatherData.rainfall.toFixed(1)}mm will contribute to soil moisture.`);
    }

    if (weatherData.temperature > 35) {
      explanations.push(`High temperature (${weatherData.temperature.toFixed(1)}°C) increases water evaporation, requiring additional irrigation.`);
    }

    if (weatherData.humidity < 40) {
      explanations.push(`Low humidity (${weatherData.humidity.toFixed(1)}%) increases transpiration rate, affecting water needs.`);
    }

    // Action explanation
    if (recommendation.action === 'irrigate') {
      explanations.push(`Recommended irrigation: ${recommendation.amount}L over ${recommendation.duration} minutes to restore optimal moisture levels.`);
    } else if (recommendation.action === 'reduce') {
      explanations.push(`Reduced irrigation recommended due to expected rainfall.`);
    } else {
      explanations.push(`No irrigation needed at this time.`);
    }

    // Confidence explanation
    if (recommendation.confidence > 85) {
      explanations.push(`High confidence (${recommendation.confidence}%) in this recommendation based on current conditions.`);
    } else {
      explanations.push(`Moderate confidence (${recommendation.confidence}%) - monitor conditions closely.`);
    }

    return explanations.join(' ');
  }

  // Generate human-readable explanation for fertilizer decision
  explainFertilizerDecision(
    recommendation: FertilizerRecommendation,
    soilData: SoilData
  ): string {
    const explanations: string[] = [];

    const npk = soilData.npk;

    // NPK analysis
    explanations.push(`Current NPK levels: N=${npk.nitrogen.toFixed(1)}%, P=${npk.phosphorus.toFixed(1)}%, K=${npk.potassium.toFixed(1)}%.`);

    // Deficiency identification
    if (npk.nitrogen < 40) {
      explanations.push(`Nitrogen is below optimal level, which affects leaf growth and overall plant vigor.`);
    }
    if (npk.phosphorus < 40) {
      explanations.push(`Phosphorus deficiency detected, impacting root development and flowering.`);
    }
    if (npk.potassium < 40) {
      explanations.push(`Potassium levels are low, affecting disease resistance and fruit quality.`);
    }

    // Recommendation explanation
    if (recommendation.amount > 0) {
      explanations.push(`Recommended ${recommendation.type} fertilizer application: ${recommendation.amount}kg using ${recommendation.applicationMethod} method.`);
    } else {
      explanations.push(`NPK levels are balanced. No immediate fertilizer application needed.`);
    }

    // Priority explanation
    if (recommendation.priority === 'urgent') {
      explanations.push(`URGENT: Immediate action required to prevent crop damage.`);
    } else if (recommendation.priority === 'high') {
      explanations.push(`High priority: Address nutrient deficiency soon to maintain crop health.`);
    }

    // Confidence
    explanations.push(`Confidence level: ${recommendation.confidence}% based on current soil analysis.`);

    return explanations.join(' ');
  }

  // Generate comprehensive explanation for zone decision
  explainZoneDecision(
    irrigation: IrrigationRecommendation,
    fertilizer: FertilizerRecommendation,
    soilData: SoilData,
    weatherData: WeatherData
  ): string {
    const irrigationExplanation = this.explainIrrigationDecision(irrigation, soilData, weatherData);
    const fertilizerExplanation = this.explainFertilizerDecision(fertilizer, soilData);

    return `IRRIGATION: ${irrigationExplanation}\n\nFERTILIZER: ${fertilizerExplanation}`;
  }
}

export const xaiEngine = new XAIEngine();

