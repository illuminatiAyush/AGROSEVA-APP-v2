// Hardware Configuration
// Central switch to toggle between mock and real hardware
// Change USE_REAL_HARDWARE to true when ESP32 is connected

import { HardwareClient } from './HardwareClient';
import { MockPHClient } from './MockPHClient';
import { HttpPHClient } from './HttpPHClient';

/**
 * Hardware Configuration
 * 
 * Set USE_REAL_HARDWARE = true when ESP32/Arduino is ready.
 * The app will automatically switch to real hardware - no code changes needed!
 */

// Toggle between mock and real hardware
const USE_REAL_HARDWARE = true;

// Hardware endpoint address
// For Arduino bridge (temporary): 'http://localhost:3000'
// For ESP32 (future): 'http://192.168.1.100' (replace with ESP32 IP)
const ESP32_IP_ADDRESS = 'http://192.168.1.43:3000'; // Bridge address (change to ESP32 IP when ready)

/**
 * Hardware Client Factory
 * 
 * Returns the appropriate hardware client based on configuration.
 * This pattern scales easily - just add more sensor clients here.
 */
export const hardwareClient: HardwareClient = USE_REAL_HARDWARE
  ? new HttpPHClient(ESP32_IP_ADDRESS)
  : new MockPHClient();

// Export config for debugging/info
export const hardwareConfig = {
  useRealHardware: USE_REAL_HARDWARE,
  esp32Address: USE_REAL_HARDWARE ? ESP32_IP_ADDRESS : null,
  clientType: USE_REAL_HARDWARE ? 'HttpPHClient' : 'MockPHClient',
} as const;

