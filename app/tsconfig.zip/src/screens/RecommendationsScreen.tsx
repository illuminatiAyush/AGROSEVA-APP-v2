// Recommendations Screen

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '@/utils/colors';

export const RecommendationsScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>AI Recommendations</Text>
      <Text style={styles.subtitle}>Irrigation & Fertilizer decisions</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
});

