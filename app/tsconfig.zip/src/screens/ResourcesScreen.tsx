// src/screens/ResourcesScreen.tsx
import React from 'react';
import { View, Text, StyleSheet, ScrollView, Dimensions } from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/theme/colors';

const screenWidth = Dimensions.get('window').width;

export default function ResourcesScreen() {
  
  // Mock Data for the  Demo
  const data = {
    labels: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    datasets: [
      {
        data: [45, 50, 40, 30, 80, 20, 45], // Water used (Liters)
        color: (opacity = 1) => `rgba(41, 182, 246, ${opacity})`, // Blue
        strokeWidth: 2
      },
      {
        data: [60, 60, 60, 60, 60, 60, 60], // Average limit
        color: (opacity = 1) => `rgba(255, 0, 0, ${opacity})`, // Red line
        strokeWidth: 2,
        withDots: false
      }
    ],
    legend: ["Water Used", "Daily Limit"]
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Resource Efficiency</Text>

      {/* SUMMARY CARDS */}
      <View style={styles.row}>
        <View style={[styles.card, { backgroundColor: '#E1F5FE' }]}>
          <Ionicons name="water" size={28} color={colors.water} />
          <Text style={styles.cardValue}>310 L</Text>
          <Text style={styles.cardLabel}>Water Used</Text>
        </View>

        <View style={[styles.card, { backgroundColor: '#E8F5E9' }]}>
          <Ionicons name="leaf" size={28} color={colors.success} />
          <Text style={styles.cardValue}>12%</Text>
          <Text style={styles.cardLabel}>Saved vs Avg</Text>
        </View>
      </View>

      {/* CHART */}
      <View style={styles.chartContainer}>
        <Text style={styles.chartTitle}>Weekly Irrigation Cycle</Text>
        <LineChart
          data={data}
          width={screenWidth - 40}
          height={220}
          chartConfig={{
            backgroundColor: "#FFF",
            backgroundGradientFrom: "#FFF",
            backgroundGradientTo: "#FFF",
            decimalPlaces: 0,
            color: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
            style: { borderRadius: 16 },
            propsForDots: { r: "5", strokeWidth: "2", stroke: colors.water }
          }}
          bezier
          style={{ marginVertical: 8, borderRadius: 16 }}
        />
      </View>

      {/* COST ANALYSIS */}
      <View style={styles.infoBox}>
        <Text style={styles.infoTitle}>Cost Analysis</Text>
        <Text style={styles.infoText}>
          By skipping irrigation on Friday (Rain Detected), you saved approx ₹450 in electricity and water pump costs.
        </Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 20, paddingTop: 50 },
  title: { fontSize: 24, fontWeight: 'bold', color: colors.text, marginBottom: 20 },
  
  row: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 20 },
  card: { width: '48%', padding: 20, borderRadius: 15, alignItems: 'center', elevation: 2 },
  cardValue: { fontSize: 24, fontWeight: 'bold', marginTop: 10, color: '#333' },
  cardLabel: { fontSize: 14, color: '#666' },

  chartContainer: { backgroundColor: '#FFF', borderRadius: 16, padding: 10, elevation: 4, marginBottom: 20 },
  chartTitle: { fontSize: 16, fontWeight: 'bold', margin: 10, color: colors.textLight },

  infoBox: { backgroundColor: '#FFF3E0', padding: 15, borderRadius: 10, borderLeftWidth: 5, borderLeftColor: colors.accent },
  infoTitle: { fontWeight: 'bold', color: '#E65100', marginBottom: 5 },
  infoText: { color: '#555', lineHeight: 20 },
});