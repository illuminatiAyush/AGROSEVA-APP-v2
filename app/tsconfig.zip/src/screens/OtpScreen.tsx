// src/screens/OtpScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, Alert, KeyboardAvoidingView, Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/theme/colors';

export default function OtpScreen({ route, navigation }: any) {
  // Get the mobile number passed from Login Screen
  const { mobile } = route.params || { mobile: '+91 9876543210' }; 
  
  const [code, setCode] = useState('');
  const [timer, setTimer] = useState(30);

  // Mock Timer Countdown
  useEffect(() => {
    let interval = setInterval(() => {
      setTimer((prev) => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleVerify = () => {
    if (code === '1234') {
      // Success!
      navigation.replace('MainTabs'); 
    } else {
      Alert.alert("Invalid Code", "Please enter 1234 to verify.");
    }
  };

  const handleResend = () => {
    setTimer(30);
    Alert.alert("OTP Resent", "A new code has been sent to your mobile.");
  };

  return (
    <View style={styles.container}>
      <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.content}>
        
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="arrow-back" size={24} color="#333" />
        </TouchableOpacity>

        <View style={styles.iconBox}>
          <Ionicons name="chatbox-ellipses" size={50} color={colors.primary} />
        </View>

        <Text style={styles.title}>Verification Code</Text>
        <Text style={styles.subtitle}>
          We have sent the verification code to {'\n'}
          <Text style={styles.bold}>{mobile}</Text>
        </Text>

        <View style={styles.inputContainer}>
          <TextInput
            style={styles.input}
            placeholder="1234"
            keyboardType="number-pad"
            maxLength={4}
            value={code}
            onChangeText={setCode}
            autoFocus
            textAlign="center"
          />
        </View>

        <TouchableOpacity style={styles.verifyBtn} onPress={handleVerify}>
          <Text style={styles.verifyText}>VERIFY</Text>
        </TouchableOpacity>

        <View style={styles.resendContainer}>
          {timer > 0 ? (
            <Text style={styles.timerText}>Resend code in 00:{timer < 10 ? `0${timer}` : timer}</Text>
          ) : (
            <TouchableOpacity onPress={handleResend}>
              <Text style={styles.resendLink}>Resend Code</Text>
            </TouchableOpacity>
          )}
        </View>

      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#FFF', padding: 20 },
  content: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  backBtn: { position: 'absolute', top: 40, left: 0, padding: 10 },
  
  iconBox: { width: 80, height: 80, borderRadius: 40, backgroundColor: '#E8F5E9', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  title: { fontSize: 24, fontWeight: 'bold', color: '#333', marginBottom: 10 },
  subtitle: { fontSize: 16, color: '#666', textAlign: 'center', marginBottom: 30, lineHeight: 24 },
  bold: { fontWeight: 'bold', color: '#000' },

  inputContainer: { width: '80%', marginBottom: 30 },
  input: { fontSize: 32, fontWeight: 'bold', borderBottomWidth: 2, borderBottomColor: colors.primary, paddingVertical: 10, letterSpacing: 10 },

  verifyBtn: { backgroundColor: colors.primary, paddingVertical: 15, paddingHorizontal: 40, borderRadius: 30, width: '100%', alignItems: 'center', elevation: 3 },
  verifyText: { color: '#FFF', fontWeight: 'bold', fontSize: 16 },

  resendContainer: { marginTop: 30 },
  timerText: { color: '#888' },
  resendLink: { color: colors.primary, fontWeight: 'bold' },
});