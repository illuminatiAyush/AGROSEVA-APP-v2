// src/screens/SettingsScreen.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Switch, ScrollView, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '@/store/useStore';
import { colors } from '@/theme/colors';
import { CommonActions } from '@react-navigation/native'; // Import this for reset action

const SettingItem = ({ icon, title, value, type, onPress }: any) => (
  <TouchableOpacity style={styles.item} onPress={onPress} disabled={type === 'switch'}>
    <View style={styles.itemLeft}>
      <View style={styles.iconBox}>
        <Ionicons name={icon} size={22} color={colors.primary} />
      </View>
      <Text style={styles.itemText}>{title}</Text>
    </View>
    {type === 'switch' ? (
      <Switch 
        value={value} 
        trackColor={{ false: '#767577', true: colors.secondary }}
        thumbColor={value ? colors.primary : '#f4f3f4'}
      />
    ) : (
      <Ionicons name="chevron-forward" size={20} color="#CCC" />
    )}
  </TouchableOpacity>
);

// Add navigation prop here
export default function SettingsScreen({ navigation }: any) {
  const { language, setLanguage } = useStore();

  const handleLanguageChange = () => {
    Alert.alert(
      "Select Language",
      "Choose your preferred language",
      [
        { text: "English", onPress: () => setLanguage('en') },
        { text: "हिंदी (Hindi)", onPress: () => setLanguage('hi') },
        { text: "मराठी (Marathi)", onPress: () => setLanguage('mr') },
      ]
    );
  };

  const handleLogout = () => {
    Alert.alert(
      "Log Out",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Log Out", 
          style: "destructive",
          onPress: () => {
            // Reset the navigation stack so user can't go back
            navigation.dispatch(
              CommonActions.reset({
                index: 0,
                routes: [{ name: 'Login' }],
              })
            );
          }
        }
      ]
    );
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Settings</Text>

      {/* PROFILE SECTION */}
      <View style={styles.profileCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>SB</Text>
        </View>
        <View>
          <Text style={styles.name}>Soham Baviskar</Text>
          <Text style={styles.id}>ID: VU1F2425052</Text>
          <Text style={styles.college}>VPPCOE VA</Text>
        </View>
      </View>

      {/* PREFERENCES */}
      <Text style={styles.sectionTitle}>App Preferences</Text>
      
      <SettingItem 
        icon="language" 
        title={`Language (${language.toUpperCase()})`} 
        onPress={handleLanguageChange} 
      />
      
      <SettingItem 
        icon="notifications" 
        title="Irrigation Alerts" 
        value={true} 
        type="switch" 
      />
      
      <SettingItem 
        icon="cloud" 
        title="Storm Warnings" 
        value={true} 
        type="switch" 
      />

      {/* SYSTEM */}
      <Text style={styles.sectionTitle}>System</Text>
      
      <SettingItem 
        icon="hardware-chip" 
        title="IoT Controller Status" 
        value={true} 
        type="switch" 
      />

      <SettingItem 
        icon="information-circle" 
        title="About Agroseva" 
        onPress={() => Alert.alert("Agroseva v1.0", "Built for Smart India Hackathon 2025\nTeam Tech Spartans")}
      />

      {/* LOGOUT BUTTON */}
      <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
        <Text style={styles.logoutText}>Log Out</Text>
      </TouchableOpacity>
      
      <Text style={styles.version}>v1.0.0 (Expo SDK 52)</Text>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 20, paddingTop: 50 },
  header: { fontSize: 28, fontWeight: 'bold', color: colors.primary, marginBottom: 20 },
  
  profileCard: { flexDirection: 'row', backgroundColor: '#FFF', padding: 20, borderRadius: 15, alignItems: 'center', marginBottom: 30, elevation: 3 },
  avatar: { width: 60, height: 60, borderRadius: 30, backgroundColor: colors.primary, justifyContent: 'center', alignItems: 'center', marginRight: 15 },
  avatarText: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
  name: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  id: { color: '#666', fontSize: 14 },
  college: { color: colors.primary, fontWeight: 'bold', fontSize: 12, marginTop: 4 },

  sectionTitle: { fontSize: 16, fontWeight: 'bold', color: '#888', marginBottom: 10, marginTop: 10 },
  
  item: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 10 },
  itemLeft: { flexDirection: 'row', alignItems: 'center' },
  iconBox: { width: 32, height: 32, borderRadius: 8, backgroundColor: '#E8F5E9', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  itemText: { fontSize: 16, color: '#333' },

  logoutBtn: { marginTop: 30, backgroundColor: '#FFEBEE', padding: 15, borderRadius: 12, alignItems: 'center' },
  logoutText: { color: colors.error, fontWeight: 'bold', fontSize: 16 },
  version: { textAlign: 'center', marginTop: 20, color: '#AAA', fontSize: 12 },
});