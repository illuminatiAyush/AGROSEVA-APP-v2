// src/screens/LoginScreen.tsx
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Image, KeyboardAvoidingView, Platform, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '@/theme/colors';

export default function LoginScreen({ navigation }: any) {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

  const handleLogin = () => {
    // Check if input is empty
    if (email.length > 0) {
      // Navigate to OTP Screen and pass the mobile number
      navigation.navigate('OtpVerification', { mobile: email });
    } else {
      Alert.alert("Required", "Please enter your Mobile Number.");
    }
  };

    const handleGuest = () => {
        navigation.replace('MainTabs');
    };

    return (
        <LinearGradient colors={[colors.primary, '#1B5E20']} style={styles.container}>
            <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : "height"} style={styles.keyboardView}>

                {/* LOGO AREA */}
                <View style={styles.logoContainer}>
                    <View style={styles.iconCircle}>
                        <Ionicons name="leaf" size={60} color={colors.primary} />
                    </View>
                    <Text style={styles.appName}>Agroseva</Text>
                    <Text style={styles.tagline}>Smart Farming Assistant</Text>
                </View>

                {/* FORM AREA */}
                <View style={styles.formContainer}>
                    <Text style={styles.welcome}>Welcome Back</Text>

                    <View style={styles.inputWrapper}>
                        <Ionicons name="person" size={20} color={colors.textLight} style={styles.inputIcon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Farmer ID / Mobile Number"
                            placeholderTextColor="#999"
                            value={email}
                            onChangeText={setEmail}
                            keyboardType="email-address"
                            autoCapitalize="none"
                        />
                    </View>

                    <View style={styles.inputWrapper}>
                        <Ionicons name="lock-closed" size={20} color={colors.textLight} style={styles.inputIcon} />
                        <TextInput
                            style={styles.input}
                            placeholder="Password"
                            placeholderTextColor="#999"
                            value={password}
                            onChangeText={setPassword}
                            secureTextEntry
                        />
                    </View>

                    <TouchableOpacity style={styles.loginBtn} onPress={handleLogin}>
                        <Text style={styles.loginText}>LOGIN</Text>
                        <Ionicons name="arrow-forward" size={20} color="#FFF" />
                    </TouchableOpacity>

                    <TouchableOpacity style={styles.guestBtn} onPress={handleGuest}>
                        <Text style={styles.guestText}>Continue as Guest</Text>
                    </TouchableOpacity>

                    <View style={styles.footer}>
                        <Text style={styles.footerText}>Powered by Farmseva</Text>
                    </View>
                </View>

            </KeyboardAvoidingView>
        </LinearGradient>
    );
}

const styles = StyleSheet.create({
    container: { flex: 1 },
    keyboardView: { flex: 1, justifyContent: 'center' },

    logoContainer: { alignItems: 'center', marginBottom: 40 },
    iconCircle: { width: 100, height: 100, backgroundColor: '#FFF', borderRadius: 50, justifyContent: 'center', alignItems: 'center', marginBottom: 15, elevation: 5 },
    appName: { fontSize: 36, fontWeight: 'bold', color: '#FFF', letterSpacing: 1 },
    tagline: { color: '#E8F5E9', fontSize: 14, opacity: 0.9 },

    formContainer: { backgroundColor: '#FFF', marginHorizontal: 20, padding: 30, borderRadius: 20, elevation: 8 },
    welcome: { fontSize: 22, fontWeight: 'bold', color: colors.text, marginBottom: 20, textAlign: 'center' },

    inputWrapper: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F5F5F5', borderRadius: 12, marginBottom: 15, paddingHorizontal: 15, height: 50, borderWidth: 1, borderColor: '#EEE' },
    inputIcon: { marginRight: 10 },
    input: { flex: 1, color: '#333', fontSize: 16 },

    loginBtn: { flexDirection: 'row', backgroundColor: colors.primary, borderRadius: 12, height: 50, justifyContent: 'center', alignItems: 'center', marginTop: 10, elevation: 3 },
    loginText: { color: '#FFF', fontWeight: 'bold', fontSize: 16, marginRight: 10 },

    guestBtn: { marginTop: 15, alignItems: 'center' },
    guestText: { color: colors.textLight, fontSize: 14, textDecorationLine: 'underline' },

    footer: { marginTop: 20, alignItems: 'center' },
    footerText: { color: '#CCC', fontSize: 12 },
});