// pH Monitoring Screen
// Displays real-time pH sensor readings with status classification

import React, { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { usePHStore } from '@/store/usePHStore';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { getPHStatus, clampPH } from '@/models/PHData';
import { colors } from '@/theme/colors';
import { formatDate, formatTime } from '@/utils/formatters';

export default function PHMonitoringScreen() {
  const { pH, timestamp, status, error, source, fetchPH } = usePHStore();

  // Fetch pH on mount
  useEffect(() => {
    fetchPH();
  }, []);

  // Get pH status classification
  const phStatus = pH !== null ? getPHStatus(pH) : null;

  // Get status color
  const getStatusColor = () => {
    if (!phStatus) return colors.textLight;
    switch (phStatus) {
      case 'acidic':
        return colors.error;
      case 'optimal':
        return colors.success;
      case 'alkaline':
        return colors.accent;
      default:
        return colors.textLight;
    }
  };

  // Get status label
  const getStatusLabel = () => {
    if (!phStatus) return 'No Data';
    switch (phStatus) {
      case 'acidic':
        return 'Acidic (< 6.0)';
      case 'optimal':
        return 'Optimal (6.0 - 7.5)';
      case 'alkaline':
        return 'Alkaline (> 7.5)';
      default:
        return 'Unknown';
    }
  };

  // Format timestamp
  const getLastUpdated = () => {
    if (!timestamp) return 'Never';
    const date = new Date(timestamp);
    return `${formatDate(date)} at ${formatTime(date)}`;
  };

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.content}
      refreshControl={
        <RefreshControl
          refreshing={status === 'loading'}
          onRefresh={fetchPH}
          tintColor={colors.primary}
        />
      }
    >
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.title}>pH Monitoring</Text>
        <Text style={styles.subtitle}>Real-time soil pH sensor readings</Text>
      </View>

      {/* Main pH Display Card */}
      <Card style={styles.mainCard}>
        <Text style={styles.label}>Current pH Level</Text>
        
        {status === 'loading' && pH === null ? (
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Reading sensor...</Text>
          </View>
        ) : error ? (
          <View style={styles.errorContainer}>
            <Text style={styles.errorText}>⚠️ {error}</Text>
            <Button
              title="Retry"
              onPress={fetchPH}
              variant="primary"
              style={styles.retryButton}
            />
          </View>
        ) : pH !== null ? (
          <>
            <View style={styles.pHContainer}>
              <Text style={[styles.pHValue, { color: getStatusColor() }]}>
                {pH.toFixed(1)}
              </Text>
              <Text style={styles.pHUnit}>pH</Text>
            </View>

            {/* Status Badge */}
            <View style={[styles.statusBadge, { backgroundColor: getStatusColor() + '20' }]}>
              <Text style={[styles.statusText, { color: getStatusColor() }]}>
                {getStatusLabel()}
              </Text>
            </View>
          </>
        ) : (
          <View style={styles.noDataContainer}>
            <Text style={styles.noDataText}>No pH data available</Text>
          </View>
        )}
      </Card>

      {/* Info Card */}
      {pH !== null && (
        <Card>
          <Text style={styles.infoLabel}>Sensor Information</Text>
          <View style={styles.infoRow}>
            <Text style={styles.infoKey}>Last Updated:</Text>
            <Text style={styles.infoValue}>{getLastUpdated()}</Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoKey}>Data Source:</Text>
            <Text style={styles.infoValue}>
              {source === 'hardware' ? '🔌 Hardware Sensor' : '🧪 Mock Data'}
            </Text>
          </View>
          <View style={styles.infoRow}>
            <Text style={styles.infoKey}>Status:</Text>
            <Text style={[styles.infoValue, { color: getStatusColor() }]}>
              {phStatus ? phStatus.toUpperCase() : 'UNKNOWN'}
            </Text>
          </View>
        </Card>
      )}

      {/* pH Range Reference Card */}
      <Card>
        <Text style={styles.infoLabel}>pH Range Reference</Text>
        <View style={styles.referenceRow}>
          <View style={[styles.referenceItem, { borderLeftColor: colors.error }]}>
            <Text style={styles.referenceLabel}>Acidic</Text>
            <Text style={styles.referenceValue}>&lt; 6.0</Text>
          </View>
          <View style={[styles.referenceItem, { borderLeftColor: colors.success }]}>
            <Text style={styles.referenceLabel}>Optimal</Text>
            <Text style={styles.referenceValue}>6.0 - 7.5</Text>
          </View>
          <View style={[styles.referenceItem, { borderLeftColor: colors.accent }]}>
            <Text style={styles.referenceLabel}>Alkaline</Text>
            <Text style={styles.referenceValue}>&gt; 7.5</Text>
          </View>
        </View>
      </Card>

      {/* Refresh Button */}
      <Button
        title="Refresh pH Reading"
        onPress={fetchPH}
        variant="primary"
        loading={status === 'loading'}
        disabled={status === 'loading'}
        style={styles.refreshButton}
      />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  content: {
    padding: 16,
    paddingTop: 60,
  },
  header: {
    marginBottom: 24,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: colors.textLight,
  },
  mainCard: {
    marginBottom: 16,
    alignItems: 'center',
    paddingVertical: 32,
  },
  label: {
    fontSize: 16,
    color: colors.textLight,
    marginBottom: 16,
  },
  pHContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'center',
    marginBottom: 16,
  },
  pHValue: {
    fontSize: 64,
    fontWeight: 'bold',
    marginRight: 8,
  },
  pHUnit: {
    fontSize: 24,
    color: colors.textLight,
    fontWeight: '600',
  },
  statusBadge: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginTop: 8,
  },
  statusText: {
    fontSize: 14,
    fontWeight: '600',
  },
  loadingContainer: {
    padding: 32,
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: colors.textLight,
  },
  errorContainer: {
    padding: 32,
    alignItems: 'center',
  },
  errorText: {
    fontSize: 16,
    color: colors.error,
    marginBottom: 16,
    textAlign: 'center',
  },
  retryButton: {
    marginTop: 8,
  },
  noDataContainer: {
    padding: 32,
    alignItems: 'center',
  },
  noDataText: {
    fontSize: 16,
    color: colors.textLight,
  },
  infoLabel: {
    fontSize: 18,
    fontWeight: '600',
    color: colors.text,
    marginBottom: 12,
  },
  infoRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  infoKey: {
    fontSize: 14,
    color: colors.textLight,
  },
  infoValue: {
    fontSize: 14,
    color: colors.text,
    fontWeight: '500',
  },
  referenceRow: {
    marginTop: 8,
  },
  referenceItem: {
    borderLeftWidth: 4,
    paddingLeft: 12,
    marginBottom: 12,
  },
  referenceLabel: {
    fontSize: 14,
    color: colors.textLight,
    marginBottom: 4,
  },
  referenceValue: {
    fontSize: 16,
    color: colors.text,
    fontWeight: '600',
  },
  refreshButton: {
    marginTop: 16,
    marginBottom: 32,
  },
});

