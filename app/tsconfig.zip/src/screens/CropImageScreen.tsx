// Crop Image Analysis Screen

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '@/utils/colors';

export const CropImageScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Crop Image Analysis</Text>
      <Text style={styles.subtitle}>Upload and analyze crop images</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
});

