// src/screens/MonitorScreen.tsx
import React from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { useStore } from '@/store/useStore';
import { colors } from '@/theme/colors';

const ProgressBar = ({ value, max, color }: { value: number, max: number, color: string }) => {
  const width = Math.min(100, (value / max) * 100);
  return (
    <View style={{ height: 10, backgroundColor: '#E0E0E0', borderRadius: 5, marginTop: 5 }}>
      <View style={{ width: `${width}%`, height: '100%', backgroundColor: color, borderRadius: 5 }} />
    </View>
  );
};

const SensorRow = ({ label, value, unit, max, icon, color }: any) => (
  <View style={styles.card}>
    <View style={styles.iconBox}>
      <MaterialCommunityIcons name={icon} size={28} color={color} />
    </View>
    <View style={{ flex: 1, marginHorizontal: 15 }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <Text style={styles.label}>{label}</Text>
        <Text style={styles.value}>{value} <Text style={styles.unit}>{unit}</Text></Text>
      </View>
      <ProgressBar value={value} max={max} color={color} />
    </View>
  </View>
);

export default function MonitorScreen() {
  const { soilData, weather } = useStore();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: 20 }}>
      <Text style={styles.header}>Field Sensors #01</Text>
      <Text style={styles.subHeader}>Last updated: Just now</Text>

      {/* SOIL SECTION */}
      <Text style={styles.sectionTitle}>Soil Health</Text>
      
      <SensorRow 
        label="Soil Moisture" 
        value={soilData.moisture} 
        unit="%" 
        max={100} 
        icon="water-percent" 
        color={colors.water} 
      />

      <SensorRow 
        label="pH Level" 
        value={soilData.ph} 
        unit="pH" 
        max={14} 
        icon="flask" 
        color={colors.secondary} 
      />

      {/* NUTRIENTS SECTION */}
      <Text style={styles.sectionTitle}>Nutrients (NPK)</Text>

      <SensorRow 
        label="Nitrogen (N)" 
        value={soilData.nitrogen} 
        unit="mg/kg" 
        max={200} 
        icon="leaf" 
        color="#43A047" 
      />
      
      <SensorRow 
        label="Phosphorus (P)" 
        value={soilData.phosphorus} 
        unit="mg/kg" 
        max={100} 
        icon="flower" 
        color="#FBC02D" 
      />
      
      <SensorRow 
        label="Potassium (K)" 
        value={soilData.potassium} 
        unit="mg/kg" 
        max={300} 
        icon="shaker" 
        color="#8D6E63" 
      />

      {/* ENVIRONMENT SECTION */}
      <Text style={styles.sectionTitle}>Environment</Text>
      <View style={styles.envContainer}>
        <View style={styles.envCard}>
          <Ionicons name="thermometer" size={24} color={colors.error} />
          <Text style={styles.envValue}>{weather.temp}°C</Text>
          <Text style={styles.envLabel}>Temp</Text>
        </View>
        
        <View style={styles.envCard}>
          <Ionicons name="water" size={24} color={colors.water} />
          <Text style={styles.envValue}>{weather.humidity}%</Text>
          <Text style={styles.envLabel}>Humidity</Text>
        </View>
      </View>

    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.background, padding: 20, paddingTop: 50 },
  header: { fontSize: 28, fontWeight: 'bold', color: colors.primary },
  subHeader: { color: colors.textLight, marginBottom: 20 },
  
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginTop: 15, marginBottom: 10, color: '#444' },
  
  card: { flexDirection: 'row', backgroundColor: '#FFF', padding: 15, borderRadius: 12, marginBottom: 12, alignItems: 'center', elevation: 2 },
  iconBox: { width: 50, height: 50, borderRadius: 25, backgroundColor: '#F5F5F5', justifyContent: 'center', alignItems: 'center' },
  label: { fontSize: 16, fontWeight: '600', color: '#333' },
  value: { fontSize: 16, fontWeight: 'bold', color: '#000' },
  unit: { fontSize: 12, color: '#888', fontWeight: 'normal' },

  envContainer: { flexDirection: 'row', justifyContent: 'space-between' },
  envCard: { width: '48%', backgroundColor: '#FFF', padding: 20, borderRadius: 12, alignItems: 'center', elevation: 2 },
  envValue: { fontSize: 24, fontWeight: 'bold', marginVertical: 5 },
  envLabel: { color: '#888' },
});