// Soil Monitoring Screen

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Colors } from '@/utils/colors';

export const SoilMonitoringScreen: React.FC = () => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Soil Monitoring</Text>
      <Text style={styles.subtitle}>Moisture, pH, NPK levels</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.background,
    padding: 20,
    paddingTop: 60,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: Colors.text,
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.textSecondary,
  },
});

