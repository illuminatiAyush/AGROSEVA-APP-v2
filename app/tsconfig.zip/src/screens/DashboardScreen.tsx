// src/screens/DashboardScreen.tsx
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl } from 'react-native';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { useStore } from '@/store/useStore';
import { AIDecisionEngine } from '@/services/AIDecisionEngine';
import { colors } from '@/theme/colors';
import { translations } from '@/utils/translations';

export default function DashboardScreen({ navigation }: any) {
  const { soilData, weather, language } = useStore(); // Get current language (en/hi/mr)
  const [refreshing, setRefreshing] = useState(false);
  const [recommendation, setRecommendation] = useState(AIDecisionEngine.analyze());

  // Select the dictionary based on language
  const t = translations[language]; 

  useEffect(() => {
    setRecommendation(AIDecisionEngine.analyze());
  }, [soilData, weather]);

  const onRefresh = () => {
    setRefreshing(true);
    setTimeout(() => setRefreshing(false), 1000);
  };

  // Helper to translate AI Action/Reason dynamically
 // Helper to translate AI Action/Reason dynamically
  const getTranslatedAI = () => {
    // FIX: We explicitly type these as 'string' to allow translated text
    let actionText: string = recommendation.action;
    let reasonText: string = recommendation.reason;
    let descText: string = recommendation.details;

    // Map the logic codes to translated strings
    if (recommendation.action === 'WAIT') {
        actionText = t.wait;
        reasonText = t.rainSoon;
        descText = t.rainSoonDesc;
    } else if (recommendation.action === 'IRRIGATE') {
        actionText = t.irrigate;
        reasonText = t.critical;
        descText = t.criticalDesc;
    } else if (recommendation.action === 'FERTILIZE') {
        actionText = t.fertilize;
        reasonText = t.nutrientDef;
        descText = t.nutrientDesc;
    } else {
        actionText = t.safe;
        reasonText = t.optimal;
        descText = t.optimalDesc;
    }

    return { actionText, reasonText, descText };
  };

  const { actionText, reasonText, descText } = getTranslatedAI();

  return (
    <View style={styles.container}>
      <ScrollView 
        contentContainerStyle={{ paddingBottom: 100 }}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* HEADER */}
        <LinearGradient colors={[colors.primary, '#1B5E20']} style={styles.header}>
          <View style={styles.headerRow}>
            <View>
              {/* Translated Greeting */}
              <Text style={styles.greeting}>{t.greeting}</Text> 
              <Text style={styles.location}>{t.location}</Text>
            </View>
            
            {/* Language Switcher Shortcut */}
            <TouchableOpacity 
              style={styles.langBtn} 
              onPress={() => navigation.navigate('Settings')}
            >
              <Text style={styles.langText}>{language.toUpperCase()}</Text>
            </TouchableOpacity>
          </View>

          {/* WEATHER */}
          <View style={styles.weatherRow}>
            <Ionicons name={weather.condition === 'Sunny' ? 'sunny' : 'rainy'} size={40} color="#FFD700" />
            <Text style={styles.temp}>{weather.temp}°C</Text>
            <Text style={styles.weatherDesc}>{weather.condition}</Text>
          </View>
        </LinearGradient>

        {/* AI DECISION CARD */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t.aiRecommendation}</Text>
          <View style={[styles.card, { borderLeftWidth: 5, borderLeftColor: recommendation.action === 'IRRIGATE' ? colors.water : colors.accent }]}>
            <View style={styles.row}>
              <MaterialCommunityIcons 
                name={recommendation.action === 'IRRIGATE' ? "water-pump" : "hand-back-right"} 
                size={32} 
                color={colors.text} 
              />
              <View style={{ marginLeft: 10, flex: 1 }}>
                <Text style={styles.aiAction}>{actionText}</Text>
                <Text style={styles.aiConfidence}>{recommendation.confidence}% Confidence</Text>
              </View>
            </View>
            <Text style={styles.aiReason}>{descText}</Text>
          </View>
        </View>

        {/* LIVE SENSORS */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>{t.soilStatus}</Text>
          <View style={styles.grid}>
            {/* Moisture */}
            <View style={styles.sensorCard}>
              <Ionicons name="water" size={24} color={colors.water} />
              <Text style={styles.sensorValue}>{soilData.moisture}%</Text>
              <Text style={styles.sensorLabel}>{t.moisture}</Text>
            </View>

            {/* pH */}
            <View style={styles.sensorCard}>
              <Ionicons name="flask" size={24} color={colors.secondary} />
              <Text style={styles.sensorValue}>{soilData.ph}</Text>
              <Text style={styles.sensorLabel}>{t.phLevel}</Text>
            </View>

            {/* NPK */}
            <View style={styles.sensorCard}>
              <MaterialCommunityIcons name="grass" size={24} color={colors.primary} />
              <Text style={styles.sensorValue}>{soilData.nitrogen}</Text>
              <Text style={styles.sensorLabel}>{t.nitrogen}</Text>
            </View>

            <View style={styles.sensorCard}>
              <MaterialCommunityIcons name="flower" size={24} color={colors.accent} />
              <Text style={styles.sensorValue}>{soilData.phosphorus}</Text>
              <Text style={styles.sensorLabel}>{t.phosphorus}</Text>
            </View>
          </View>
        </View>

      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F2F2F2' },
  header: { padding: 20, paddingTop: 60, borderBottomLeftRadius: 30, borderBottomRightRadius: 30 },
  headerRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  greeting: { color: '#FFF', fontSize: 24, fontWeight: 'bold' },
  location: { color: '#E8F5E9', fontSize: 14 },
  langBtn: { backgroundColor: 'rgba(255,255,255,0.2)', padding: 8, borderRadius: 12 },
  langText: { color: '#FFF', fontWeight: 'bold' },
  weatherRow: { marginTop: 20, flexDirection: 'row', alignItems: 'center' },
  temp: { color: '#FFF', fontSize: 32, fontWeight: 'bold', marginLeft: 10, marginRight: 10 },
  weatherDesc: { color: '#E8F5E9', fontSize: 16 },
  
  section: { padding: 20 },
  sectionTitle: { fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: '#333' },
  
  card: { backgroundColor: '#FFF', padding: 20, borderRadius: 16, elevation: 4, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 10 },
  row: { flexDirection: 'row', alignItems: 'center', marginBottom: 10 },
  aiAction: { fontSize: 20, fontWeight: 'bold', color: colors.primary },
  aiConfidence: { fontSize: 12, color: '#888' },
  aiReason: { fontSize: 14, color: '#555', lineHeight: 20 },

  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
  sensorCard: { width: '48%', backgroundColor: '#FFF', padding: 15, borderRadius: 16, marginBottom: 15, alignItems: 'center', elevation: 2 },
  sensorValue: { fontSize: 22, fontWeight: 'bold', marginTop: 5, color: '#333' },
  sensorLabel: { fontSize: 12, color: '#888' },
});