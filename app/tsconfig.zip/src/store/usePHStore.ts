// pH Zustand Store
// Manages pH sensor state and provides actions for fetching pH data

import { create } from 'zustand';
import { PHData } from '@/models/PHData';
import { phService } from '@/services/PHService';

interface PHState {
  // State
  pH: number | null;
  timestamp: number | null;
  status: 'idle' | 'loading' | 'error';
  error: string | null;
  source: 'mock' | 'hardware' | null;

  // Actions
  fetchPH: () => Promise<void>;
  reset: () => void;
}

/**
 * pH Store
 * 
 * Manages pH sensor state:
 * - Current pH value and timestamp
 * - Loading/error states
 * - Data source (mock/hardware)
 * 
 * Usage:
 *   const { pH, status, fetchPH } = usePHStore();
 *   await fetchPH();
 */
export const usePHStore = create<PHState>((set, get) => ({
  // Initial state
  pH: null,
  timestamp: null,
  status: 'idle',
  error: null,
  source: null,

  // Fetch pH from sensor
  fetchPH: async () => {
    set({ status: 'loading', error: null });

    try {
      const data: PHData = await phService.fetchPH();

      set({
        pH: data.pH,
        timestamp: data.timestamp,
        source: data.source,
        status: 'idle',
        error: null,
      });
    } catch (error: any) {
      set({
        status: 'error',
        error: error.message || 'Failed to fetch pH data',
      });
    }
  },

  // Reset store to initial state
  reset: () => {
    set({
      pH: null,
      timestamp: null,
      status: 'idle',
      error: null,
      source: null,
    });
  },
}));

