// src/utils/translations.ts

export const translations = {
  en: {
    // Dashboard
    greeting: "Namaste, Farmer",
    location: "Maharashtra, India",
    aiRecommendation: "AI Recommendation",
    soilStatus: "Soil Status (Live)",
    moisture: "Moisture",
    phLevel: "pH Level",
    nitrogen: "Nitrogen",
    phosphorus: "Phosphorus",
    irrigate: "IRRIGATE",
    wait: "WAIT",
    safe: "SAFE",
    fertilize: "FERTILIZE",
    
    // AI Reasons
    rainSoon: "Rain Forecasted Soon",
    rainSoonDesc: "Soil is dry (40%), but rain is expected in 24h. Skipping irrigation to save water.",
    critical: "Critical Soil Moisture",
    criticalDesc: "Moisture is critical. No rain forecast. Pump activation recommended.",
    nutrientDef: "Nutrient Deficiency",
    nutrientDesc: "N-P-K levels are below optimal range. Recommended NPK 19:19:19 blend.",
    optimal: "Optimal Conditions",
    optimalDesc: "Soil moisture and nutrient levels are healthy. No action required.",

    // Weather
    sunny: "Sunny",
    rainy: "Rainy",
    cloudy: "Cloudy",
  },

  hi: {
    greeting: "नमस्ते, किसान भाई",
    location: "महाराष्ट्र, भारत",
    aiRecommendation: "AI सलाह",
    soilStatus: "मिट्टी की स्थिति (लाइव)",
    moisture: "नमी",
    phLevel: "pH स्तर",
    nitrogen: "नाइट्रोजन",
    phosphorus: "फॉस्फोरस",
    irrigate: "सिंचाई करें",
    wait: "रुको",
    safe: "सुरक्षित",
    fertilize: "खाद डालें",

    rainSoon: "जल्द बारिश की संभावना",
    rainSoonDesc: "मिट्टी सूखी है (40%), लेकिन 24 घंटे में बारिश की उम्मीद है। पानी बचाने के लिए सिंचाई रोकें।",
    critical: "महत्वपूर्ण नमी स्तर",
    criticalDesc: "नमी बहुत कम है। बारिश का अनुमान नहीं है। पंप चालू करने की सलाह दी जाती है।",
    nutrientDef: "पोषक तत्वों की कमी",
    nutrientDesc: "N-P-K स्तर इष्टतम सीमा से नीचे हैं। NPK 19:19:19 मिश्रण की सिफारिश की गई है।",
    optimal: "अनुकूल स्थिति",
    optimalDesc: "मिट्टी की नमी और पोषक तत्व स्वस्थ हैं। कोई कार्रवाई आवश्यक नहीं है।",

    sunny: "धूप",
    rainy: "बारिश",
    cloudy: "बादल",
  },

  mr: {
    greeting: "नमस्ते, शेतकरी दादा",
    location: "महाराष्ट्र, भारत",
    aiRecommendation: "AI शिफारस",
    soilStatus: "मातीची स्थिती (लाइव)",
    moisture: "ओलावा",
    phLevel: "pH पातळी",
    nitrogen: "नायट्रोजन",
    phosphorus: "फॉस्फरस",
    irrigate: "सिंचन करा",
    wait: "थांबा",
    safe: "सुरक्षित",
    fertilize: "खत टाका",

    rainSoon: "लवकरच पावसाची शक्यता",
    rainSoonDesc: "जमीन कोरडी आहे (40%), पण 24 तासांत पावसाची अपेक्षा आहे. पाणी वाचवण्यासाठी सिंचन थांबवा.",
    critical: "गंभीर ओलावा पातळी",
    criticalDesc: "ओलावा खूप कमी आहे. पावसाचा अंदाज नाही. पंप चालू करण्याची शिफारस केली जाते.",
    nutrientDef: "पोषक तत्वांची कमतरता",
    nutrientDesc: "N-P-K पातळी योग्य मर्यादेखाली आहे. NPK 19:19:19 मिश्रणाची शिफारस केली आहे.",
    optimal: "उत्तम स्थिती",
    optimalDesc: "मातीचा ओलावा आणि पोषक तत्वे निरोगी आहेत. कोणत्याही कृतीची आवश्यकता नाही.",

    sunny: "सूर्यप्रकाश",
    rainy: "पाऊस",
    cloudy: "ढगाळ",
  }
};